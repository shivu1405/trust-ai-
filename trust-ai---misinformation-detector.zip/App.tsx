import React, { useState, useEffect, useCallback } from 'react';
import { AnalysisResult, HistoryItem, InputType } from './types';
import { analyzeContent, streamChatbotResponse } from './services/geminiService';
import Header from './components/Header';
import AnalysisView from './components/AnalysisView';
import HistoryView from './components/HistoryView';
import Chatbot from './components/Chatbot';
import { LearnModal, TransparencyModal } from './components/Modals';

const App: React.FC = () => {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [activeTab, setActiveTab] = useState<'analysis' | 'history' | 'learn' | 'transparency'>('analysis');
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([]);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    const savedHistory = localStorage.getItem('trust-ai-history');
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    }
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  const toggleTheme = () => {
    setTheme(prevTheme => {
      const newTheme = prevTheme === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
      document.documentElement.classList.toggle('dark', newTheme === 'dark');
      return newTheme;
    });
  };

  const handleAnalysis = useCallback(async (inputType: InputType, content: string, fileData: { name: string; type: string; data: string } | null) => {
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setActiveTab('analysis');

    try {
      const result = await analyzeContent(inputType, content, fileData);
      setAnalysisResult(result);
      
      const newHistoryItem: HistoryItem = {
        id: new Date().toISOString(),
        input: {
          type: inputType,
          content: content,
          fileName: fileData?.name,
        },
        result: result,
        timestamp: new Date().toLocaleString(),
      };
      
      setHistory(prevHistory => {
        const updatedHistory = [newHistoryItem, ...prevHistory].slice(0, 20); // Keep last 20
        localStorage.setItem('trust-ai-history', JSON.stringify(updatedHistory));
        return updatedHistory;
      });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleNewAnalysis = () => {
    setAnalysisResult(null);
    setError(null);
  };

  const handleFollowUp = (question: string) => {
    const userMessage = { role: 'user' as const, text: question };
    const messagesWithUser = [...chatMessages, userMessage];
    setChatMessages(messagesWithUser);
    setIsChatbotOpen(true);
    handleChatbotSend(question, messagesWithUser);
  };

  const handleChatbotSend = async (message: string, currentMessages: { role: 'user' | 'model'; text: string }[]) => {
      try {
        // Add an empty placeholder for the model's response to stream into
        setChatMessages(prev => [...prev, { role: 'model', text: '' }]);
        
        const responseStream = await streamChatbotResponse(currentMessages);
        
        for await (const chunk of responseStream) {
          const chunkText = chunk.text;
          setChatMessages(prev => {
            const newMessages = [...prev];
            // Append the new text chunk to the last message (the model's response)
            newMessages[newMessages.length - 1].text += chunkText;
            return newMessages;
          });
        }
      } catch (err) {
        setChatMessages(prev => {
            const newMessages = [...prev];
            newMessages[newMessages.length - 1].text = "Sorry, I encountered an error. Please try again.";
            return newMessages;
        });
      }
  };


  const loadFromHistory = (item: HistoryItem) => {
    setAnalysisResult(item.result);
    setActiveTab('analysis');
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('trust-ai-history');
    setAnalysisResult(null);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'analysis':
        return (
          <AnalysisView
            onAnalyze={handleAnalysis}
            isLoading={isLoading}
            error={error}
            analysisResult={analysisResult}
            onNewAnalysis={handleNewAnalysis}
            onFollowUp={handleFollowUp}
          />
        );
      case 'history':
        return <HistoryView history={history} onLoad={loadFromHistory} onClear={clearHistory} />;
      case 'learn':
        return (
          <>
            <AnalysisView onAnalyze={handleAnalysis} isLoading={isLoading} error={error} analysisResult={analysisResult} onNewAnalysis={handleNewAnalysis} onFollowUp={handleFollowUp}/>
            <LearnModal onClose={() => setActiveTab('analysis')} />
          </>
        );
      case 'transparency':
        return (
          <>
            <AnalysisView onAnalyze={handleAnalysis} isLoading={isLoading} error={error} analysisResult={analysisResult} onNewAnalysis={handleNewAnalysis} onFollowUp={handleFollowUp}/>
            <TransparencyModal onClose={() => setActiveTab('analysis')} />
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen text-text-light dark:text-text-dark bg-background-light dark:bg-background-dark font-sans transition-colors duration-300">
      <Header theme={theme} toggleTheme={toggleTheme} activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="p-4 md:p-8">
        {renderContent()}
      </main>
      <Chatbot 
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        onOpen={() => setIsChatbotOpen(true)}
        messages={chatMessages}
        onSend={handleChatbotSend}
        setMessages={setChatMessages}
      />
    </div>
  );
};

export default App;