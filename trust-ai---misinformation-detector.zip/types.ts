
export interface Source {
  url: string;
  title: string;
  trustScore: number;
  timestamp: string;
}

export interface EntityAnalysis {
  keyEntities: {
    name: string;
    type: string; // e.g., Person, Organization, Location
  }[];
  relationships: string[]; // e.g., "John Doe works for Acme Corp."
  imageDescriptions: string[]; // e.g., "An image of a bar chart showing Q3 sales."
}

export interface AnalysisResult {
  summary: string;
  credibility: {
    score: number;
    confidence: number;
    explanation: string;
  };
  sentiment: {
    tone: string;
    bias: string;
    score: number;
  };
  unbiasedVersion: string;
  sources: {
    verified: Source[];
    nonVerified: Source[];
  };
  insights: {
    title: string;
    items: { key: string; value: string }[];
  };
  followUpQuestions: string[];
  entityAnalysis?: EntityAnalysis;
  urlAnalysis?: {
    domain: string;
    reputation: string;
    age: string;
  };
  imageAnalysis?: {
    reverseSearch: string;
    metadata: string;
  };
}

export interface HistoryItem {
  id: string;
  input: {
    type: InputType;
    content: string;
    fileName?: string;
  };
  result: AnalysisResult;
  timestamp: string;
}

export enum InputType {
    TEXT = 'text',
    URL = 'url',
    FILE = 'file',
    IMAGE = 'image',
}
