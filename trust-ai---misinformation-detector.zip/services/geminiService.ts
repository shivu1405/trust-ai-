import { GoogleGenAI, Type, GenerateContentResponse } from '@google/genai';
import { AnalysisResult, InputType } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        summary: { type: Type.STRING, description: "A concise summary of the content provided." },
        credibility: {
            type: Type.OBJECT,
            properties: {
                score: { type: Type.INTEGER, description: "Credibility score from 0 to 100." },
                confidence: { type: Type.INTEGER, description: "Confidence level of the analysis from 0 to 100." },
                explanation: { type: Type.STRING, description: "Detailed explanation for the credibility score, highlighting unreliable sources, emotional bias, or factual inconsistencies." }
            },
            required: ["score", "confidence", "explanation"]
        },
        sentiment: {
            type: Type.OBJECT,
            properties: {
                tone: { type: Type.STRING, description: "Detected tone (e.g., Neutral, Persuasive, Alarmist)." },
                bias: { type: Type.STRING, description: "Detected political or ideological bias (e.g., Left-leaning, Right-leaning, Neutral)." },
                score: { type: Type.INTEGER, description: "Sentiment score from -100 (very negative) to 100 (very positive)." }
            },
            required: ["tone", "bias", "score"]
        },
        unbiasedVersion: { type: Type.STRING, description: "A rewritten, neutral, and unbiased version of the original text." },
        sources: {
            type: Type.OBJECT,
            properties: {
                verified: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            url: { type: Type.STRING },
                            title: { type: Type.STRING },
                            trustScore: { type: Type.INTEGER },
                            timestamp: { type: Type.STRING, description: "Last checked timestamp in ISO 8601 format." }
                        },
                        required: ["url", "title", "trustScore", "timestamp"]
                    }
                },
                nonVerified: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            url: { type: Type.STRING },
                            title: { type: Type.STRING },
                            trustScore: { type: Type.INTEGER },
                            timestamp: { type: Type.STRING, description: "Last checked timestamp in ISO 8601 format." }
                        },
                        required: ["url", "title", "trustScore", "timestamp"]
                    }
                }
            },
            required: ["verified", "nonVerified"]
        },
        insights: {
            type: Type.OBJECT,
            description: "Key insights or metadata extracted from the content. For URLs, domain info. For images, metadata. For text, key entities or topics.",
            properties: {
                title: { type: Type.STRING, description: "A title for the insights section (e.g., 'URL Metadata', 'Image Properties')." },
                items: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            key: { type: Type.STRING },
                            value: { type: Type.STRING }
                        },
                        required: ["key", "value"]
                    }
                }
            },
            required: ["title", "items"]
        },
        followUpQuestions: {
            type: Type.ARRAY,
            description: "A list of 3-4 suggested follow-up questions the user might have about the analysis.",
            items: { type: Type.STRING }
        },
        entityAnalysis: {
            type: Type.OBJECT,
            description: "Analysis of key entities, their relationships, and descriptions of any images mentioned in the document. This should only be populated for file uploads.",
            properties: {
                keyEntities: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING },
                            type: { type: Type.STRING, description: "e.g., Person, Organization, Location" }
                        },
                        required: ["name", "type"]
                    }
                },
                relationships: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "A list of sentences describing relationships between entities."
                },
                imageDescriptions: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "A list of descriptions for any images found or mentioned in the document."
                }
            },
            required: ["keyEntities", "relationships", "imageDescriptions"]
        },
    },
    required: ["summary", "credibility", "sentiment", "unbiasedVersion", "sources", "insights", "followUpQuestions"]
};

const buildPrompt = (inputType: InputType, content: string, fileData: { name: string; type: string; data: string } | null) => {
    let analysisTarget = '';
    const isTextBasedAnalysis = [InputType.TEXT, InputType.URL, InputType.FILE].includes(inputType);
    
    switch (inputType) {
        case InputType.TEXT: analysisTarget = `The following text: "${content}"`; break;
        case InputType.URL: analysisTarget = `The content from the URL: ${content}`; break;
        case InputType.IMAGE: analysisTarget = `The provided image named "${fileData?.name}".`; break;
        case InputType.FILE: analysisTarget = `The content of the file named "${fileData?.name}": "${content}"`; break;
        default: analysisTarget = `The following text: "${content}"`;
    }
    
    return `
      Act as a world-class misinformation detection AI called "Trust AI". Your purpose is to analyze content for credibility, bias, and factual accuracy.
      You have access to simulated versions of Google Fact Check, Snopes, NewsAPI, domain reputation databases, and reverse image search tools.
      
      Analyze ${analysisTarget} and provide a detailed report.
      
      Your analysis must cover:
      1.  **Credibility Assessment:** Assign a score from 0 (completely false) to 100 (completely true). Provide a confidence level for your own analysis. Explain your reasoning.
      2.  **Sentiment and Bias:** Determine the tone, potential bias, and overall sentiment.
      3.  **Unbiased Rewrite:** Provide a neutral, fact-based version of the text if it's flagged as biased.
      4.  **Source Verification:** List verified, reputable sources that support or debunk the claims. Also list any non-verified or questionable sources.
      5.  **Insights & Metadata:** Extract key metadata. For URLs, provide domain reputation and age. For images, provide simulated properties like resolution or signs of manipulation. For text/files, extract key entities or topics.
      6.  **Follow-up Questions:** Suggest 3 relevant questions a user might ask to dig deeper into the analysis (e.g., "Tell me more about [source name]", "Why is the tone considered [tone]?").
      ${isTextBasedAnalysis ? `
      7.  **Key Entities and Insights:** Since this is a text-based analysis, perform a deep-dive:
          -   Identify all key entities (people, organizations, locations, etc.).
          -   Describe the key relationships between these entities.
          -   If the text mentions or describes any images, provide a brief description for each.
          -   Populate the 'entityAnalysis' field in the JSON response with this information.
      ` : ''}
      
      Return your entire response as a single, valid JSON object that strictly adheres to the provided schema.
      For inputs that are not text, URL, or file based (i.e., for images), you must omit the 'entityAnalysis' field from the JSON output.
    `;
}

export const analyzeContent = async (
    inputType: InputType,
    content: string,
    fileData: { name: string; type: string; data: string } | null
): Promise<AnalysisResult> => {
    
    const prompt = buildPrompt(inputType, content, fileData);
    const parts: any[] = [{ text: prompt }];

    if (inputType === InputType.IMAGE && fileData && fileData.type.startsWith('image/')) {
        parts.push({ inlineData: { mimeType: fileData.type, data: fileData.data } });
    }

    try {
        const responseStream = await ai.models.generateContentStream({
            model: 'gemini-2.5-flash',
            contents: { parts: parts },
            config: {
                responseMimeType: 'application/json',
                responseSchema: responseSchema,
                temperature: 0.2,
                thinkingConfig: { thinkingBudget: 0 },
            }
        });

        let accumulatedJson = "";
        for await (const chunk of responseStream) {
            accumulatedJson += chunk.text;
        }

        const result = JSON.parse(accumulatedJson) as AnalysisResult;
        return result;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to analyze content. The AI model could not process the request.");
    }
};

export const streamChatbotResponse = async (messages: { role: 'user' | 'model'; text: string }[]): Promise<AsyncGenerator<GenerateContentResponse>> => {
    const history = messages.slice(0, -1).map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
    }));
    const latestMessage = messages[messages.length - 1].text;
    
    const systemInstruction = "You are a friendly and helpful AI assistant for the Trust AI website. Your goal is to answer user questions about their analysis results, explain concepts of misinformation, and guide them on how to use the website. Keep your answers concise and easy to understand.";

    try {
        const chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            history: history,
            config: { 
                systemInstruction,
                thinkingConfig: { thinkingBudget: 0 },
            }
        });
        const responseStream = await chat.sendMessageStream({ message: latestMessage });
        return responseStream;
    } catch (error) {
        console.error("Error in chatbot:", error);
        throw new Error("I'm sorry, I wasn't able to process that. Please try again.");
    }
};