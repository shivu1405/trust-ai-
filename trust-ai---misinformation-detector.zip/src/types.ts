
export interface Source {
  url: string;
  title: string;
  trustScore: number;
  timestamp: string;
}

export interface AnalysisResult {
  summary: string;
  credibility: {
    score: number;
    confidence: number;
    explanation: string;
  };
  sentiment: {
    tone: string;
    bias: string;
    score: number;
  };
  unbiasedVersion: string;
  sources: {
    verified: Source[];
    nonVerified: Source[];
  };
  insights: {
    title: string;
    items: { key: string; value: string }[];
  };
  followUpQuestions: string[];
  urlAnalysis?: {
    domain: string;
    reputation: string;
    age: string;
  };
  imageAnalysis?: {
    reverseSearch: string;
    metadata: string;
  };
}

export interface HistoryItem {
  id: string;
  input: {
    // FIX: Use the InputType enum to allow all valid input types.
    type: InputType;
    content: string;
    fileName?: string;
  };
  result: AnalysisResult;
  timestamp: string;
}

export enum InputType {
    TEXT = 'text',
    URL = 'url',
    FILE = 'file',
    IMAGE = 'image',
    PDF = 'pdf'
}
