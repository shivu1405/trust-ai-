import React, { useState, useEffect, useRef } from 'react';
import { ShieldCheck, Sun, Moon, BookOpen, Info, Clock, Search, Menu, X } from './Icons';

interface HeaderProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  activeTab: 'analysis' | 'history' | 'learn' | 'transparency';
  setActiveTab: (tab: 'analysis' | 'history' | 'learn' | 'transparency') => void;
}

const NavButton: React.FC<{
    onClick: () => void;
    isActive: boolean;
    children: React.ReactNode;
    className?: string;
}> = ({ onClick, isActive, children, className = '' }) => {
    const activeClasses = 'text-primary dark:text-primary-light bg-primary/10 dark:bg-primary-light/10';
    const inactiveClasses = 'text-text-secondary-light dark:text-text-secondary-dark hover:text-primary dark:hover:text-primary-light hover:bg-gray-200 dark:hover:bg-gray-700';
    return (
        <button
            onClick={onClick}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${isActive ? activeClasses : inactiveClasses} ${className}`}
        >
            {children}
        </button>
    );
};

const MenuItem: React.FC<{ onClick: () => void; children: React.ReactNode; }> = ({ onClick, children }) => (
    <button
        onClick={onClick}
        className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-text-light dark:text-text-dark hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
    >
        {children}
    </button>
);


const Header: React.FC<HeaderProps> = ({ theme, toggleTheme, activeTab, setActiveTab }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const isMenuActive = ['history', 'learn', 'transparency'].includes(activeTab);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
            setIsMenuOpen(false);
        }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
        document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <header className="bg-card-light dark:bg-card-dark border-b border-border-light dark:border-border-dark shadow-sm sticky top-0 z-20">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-8 w-8 text-primary" />
            <h1 className="text-xl md:text-2xl font-bold text-text-light dark:text-text-dark whitespace-nowrap">Trust AI</h1>
          </div>
          
          <div className="flex items-center">
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              <NavButton onClick={() => setActiveTab('analysis')} isActive={activeTab === 'analysis'}>
                  <Search className="h-4 w-4" /> Analysis
              </NavButton>
              <NavButton onClick={() => setActiveTab('history')} isActive={activeTab === 'history'}>
                  <Clock className="h-4 w-4" /> History
              </NavButton>
              <NavButton onClick={() => setActiveTab('learn')} isActive={activeTab === 'learn'}>
                  <BookOpen className="h-4 w-4" /> Learn
              </NavButton>
              <NavButton onClick={() => setActiveTab('transparency')} isActive={activeTab === 'transparency'}>
                  <Info className="h-4 w-4" /> Transparency
              </NavButton>
            </nav>

            {/* Mobile Navigation */}
            <nav className="flex md:hidden items-center gap-1 ml-2">
              <NavButton onClick={() => setActiveTab('analysis')} isActive={activeTab === 'analysis'} className="p-2">
                <Search className="h-5 w-5" />
              </NavButton>
              <div className="relative" ref={menuRef}>
                <button
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                    className={`p-2 rounded-md transition-colors ${
                        isMenuActive || isMenuOpen
                            ? 'text-primary dark:text-primary-light bg-primary/10 dark:bg-primary-light/10'
                            : 'text-text-secondary-light dark:text-text-secondary-dark hover:text-primary dark:hover:text-primary-light hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                >
                    <Menu className="h-5 w-5" />
                </button>
                {isMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 origin-top-right bg-card-light dark:bg-card-dark rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-30">
                      <div className="py-1">
                          <MenuItem onClick={() => { setActiveTab('history'); setIsMenuOpen(false); }}>
                            <Clock className="h-4 w-4" /> History
                          </MenuItem>
                          <MenuItem onClick={() => { setActiveTab('learn'); setIsMenuOpen(false); }}>
                            <BookOpen className="h-4 w-4" /> Learn
                          </MenuItem>
                          <MenuItem onClick={() => { setActiveTab('transparency'); setIsMenuOpen(false); }}>
                            <Info className="h-4 w-4" /> Transparency
                          </MenuItem>
                      </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Theme Toggle (Common) */}
            <button
              onClick={toggleTheme}
              className="ml-2 p-2 rounded-full text-text-secondary-light dark:text-text-secondary-dark hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
