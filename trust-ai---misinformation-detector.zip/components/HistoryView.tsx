
import React from 'react';
import { HistoryItem } from '../types';
import { Clock, Trash2, FileText, Link } from './Icons';

interface HistoryViewProps {
  history: HistoryItem[];
  onLoad: (item: HistoryItem) => void;
  onClear: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ history, onLoad, onClear }) => {

  const InputIcon = ({ type }: { type: string }) => {
    switch (type) {
        case 'url': return <Link className="h-5 w-5 text-text-secondary-light dark:text-text-secondary-dark" />;
        case 'file':
        case 'image':
            return <FileText className="h-5 w-5 text-text-secondary-light dark:text-text-secondary-dark" />;
        default: return <FileText className="h-5 w-5 text-text-secondary-light dark:text-text-secondary-dark" />;
    }
  }

  return (
    <div className="container mx-auto max-w-7xl">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-border-light dark:border-border-dark">
            <div className="flex items-center gap-3">
                <Clock className="h-8 w-8 text-primary" />
                <h2 className="text-3xl font-bold">Analysis History</h2>
            </div>
            {history.length > 0 && (
            <button onClick={onClear} className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg text-red-600 dark:text-red-400 bg-red-500/10 hover:bg-red-500/20 transition-colors">
                <Trash2 className="h-4 w-4" /> Clear History
            </button>
            )}
      </div>

      {history.length === 0 ? (
          <div className="text-center py-16">
            <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold">No History Yet</h3>
            <p className="text-text-secondary-light dark:text-text-secondary-dark mt-2">Your past analyses will be saved here.</p>
          </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {history.map(item => (
                    <div
                    key={item.id}
                    onClick={() => onLoad(item)}
                    className="bg-card-light dark:bg-card-dark p-5 rounded-xl border border-border-light dark:border-border-dark shadow-sm hover:shadow-lg hover:border-primary dark:hover:border-primary-light cursor-pointer transition-all duration-200 group"
                    >
                        <div className="flex justify-between items-start gap-4">
                            <div className="flex items-start gap-3 flex-grow min-w-0">
                                <div className="mt-1 flex-shrink-0">
                                    <InputIcon type={item.input.type} />
                                </div>
                                <div className="min-w-0">
                                    <p className="text-base font-semibold truncate group-hover:text-primary dark:group-hover:text-primary-light">
                                        {item.input.fileName || item.input.content}
                                    </p>
                                    <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark mt-1">{item.timestamp}</p>
                                </div>
                            </div>
                            <div className="flex-shrink-0 text-right">
                                <span className={`text-2xl font-bold ${item.result.credibility.score > 70 ? 'text-green-500' : item.result.credibility.score > 40 ? 'text-yellow-500' : 'text-red-500'}`}>
                                    {item.result.credibility.score}<span className="text-lg">%</span>
                                </span>
                                <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark">Credibility</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        )}
    </div>
  );
};

export default HistoryView;
