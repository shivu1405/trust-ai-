import React from 'react';
import { AnalysisResult, InputType } from '../types';
import InputController from './InputController';
import ResultsDashboard from './ResultsDashboard';
import ResultsDashboardSkeleton from './ResultsDashboardSkeleton';
import { ShieldCheck } from './Icons';

interface AnalysisViewProps {
  onAnalyze: (inputType: InputType, content: string, fileData: { name: string; type: string; data: string } | null) => void;
  isLoading: boolean;
  error: string | null;
  analysisResult: AnalysisResult | null;
  onNewAnalysis: () => void;
  onFollowUp: (question: string) => void;
}

const AnalysisView: React.FC<AnalysisViewProps> = ({ onAnalyze, isLoading, error, analysisResult, onNewAnalysis, onFollowUp }) => {
  return (
    <div className="container mx-auto max-w-7xl">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 flex flex-col gap-8">
          <InputController onAnalyze={onAnalyze} isLoading={isLoading} />
        </div>
        <div className="lg:col-span-7">
          {isLoading && <ResultsDashboardSkeleton />}
          {error && <div className="bg-red-100 dark:bg-red-900/50 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg" role="alert">{error}</div>}
          {analysisResult && !isLoading && <ResultsDashboard result={analysisResult} onNewAnalysis={onNewAnalysis} onFollowUp={onFollowUp} />}
          {!isLoading && !error && !analysisResult && (
            <div className="flex items-center justify-center h-full min-h-[500px] bg-card-light dark:bg-card-dark rounded-xl border border-border-light dark:border-border-dark p-8">
              <div className="text-center">
                <ShieldCheck className="h-16 w-16 text-primary mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Welcome to Trust AI</h2>
                <p className="text-text-secondary-light dark:text-text-secondary-dark">Select an input method on the left to begin your analysis.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;