import React, { useState, useEffect } from 'react';
import { Mic, MicOff } from './Icons';

interface VoiceInputProps {
  onTranscript: (transcript: string) => void;
  disabled?: boolean;
}

// Add type definitions for the Web Speech API, as they are not included in TypeScript's standard DOM library.
interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}

// Check for SpeechRecognition API, casting `window` to `any` to access non-standard properties.
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const recognition = SpeechRecognition ? new SpeechRecognition() : null;

if (recognition) {
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';
}

const VoiceInput: React.FC<VoiceInputProps> = ({ onTranscript, disabled = false }) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(!!recognition);

  useEffect(() => {
    if (!recognition) return;

    const handleResult = (event: SpeechRecognitionEvent) => {
      let finalTranscriptChunk = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscriptChunk += event.results[i][0].transcript;
        }
      }
      // If a new final chunk is recognized, send it to the parent.
      if (finalTranscriptChunk) {
        onTranscript(finalTranscriptChunk.trim());
      }
    };

    const handleEnd = () => {
        // The 'end' event is the single source of truth for when recognition has stopped.
        // It ensures the state is updated only after the browser API confirms it.
        setIsListening(false);
    };

    recognition.addEventListener('result', handleResult);
    recognition.addEventListener('end', handleEnd);

    return () => {
      recognition.removeEventListener('result', handleResult);
      recognition.removeEventListener('end', handleEnd);
      try {
        // Ensure recognition is stopped when the component unmounts.
        if (isListening) {
            recognition.stop();
        }
      } catch (e) {
        // Ignore error if recognition wasn't running.
      }
    };
  }, [onTranscript, isListening]);

  const toggleListening = () => {
    if (!recognition || disabled) return;

    if (isListening) {
      // Calling stop() will trigger the 'end' event, which handles state changes.
      recognition.stop();
    } else {
      try {
        recognition.start();
        setIsListening(true);
      } catch (err) {
        // This error can happen if start() is called when it's already running,
        // which indicates a state mismatch. The 'end' event handler should prevent this,
        // but we log it for robustness.
        console.error("Speech recognition error:", err);
      }
    }
  };

  if (!isSupported) {
    return <div className="text-xs text-red-500 p-2 text-center">Voice input not supported on this browser.</div>;
  }
  
  return (
    <button
      onClick={toggleListening}
      disabled={disabled}
      className={`w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
        isListening 
          ? 'bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-300' 
          : 'bg-background-light dark:bg-background-dark text-text-secondary-light dark:text-text-secondary-dark hover:bg-gray-200 dark:hover:bg-gray-700 border border-border-light dark:border-border-dark'
      }`}
    >
      {isListening ? (
        <>
          <MicOff className="h-5 w-5" />
          <span className="animate-pulse">Listening...</span>
        </>
      ) : (
        <>
          <Mic className="h-5 w-5" />
           <span>Transcribe Voice</span>
        </>
      )}
    </button>
  );
};

export default VoiceInput;