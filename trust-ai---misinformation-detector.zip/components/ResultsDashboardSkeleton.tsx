import React, { useState, useEffect } from 'react';

const SkeletonCard: React.FC<{className?: string}> = ({className}) => (
    <div className={`bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark ${className}`}>
        <div className="h-5 w-1/3 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
        <div className="space-y-3">
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
        </div>
    </div>
);

const ResultsDashboardSkeleton: React.FC = () => {
    const [loadingMessage, setLoadingMessage] = useState("AI is warming up...");

    useEffect(() => {
        const messages = [
            "Analyzing content structure...",
            "Cross-referencing with fact databases...",
            "Detecting sentiment and bias...",
            "Verifying sources...",
            "Compiling the final report..."
        ];
        let messageIndex = 0;
        const interval = setInterval(() => {
            messageIndex = (messageIndex + 1) % messages.length;
            setLoadingMessage(messages[messageIndex]);
        }, 2500);
        return () => clearInterval(interval);
    }, []);

  return (
    <div className="space-y-6 animate-pulse">
       <div className="flex justify-between items-center">
            <div className="h-8 w-48 bg-gray-300 dark:bg-gray-700 rounded"></div>
            <div className="flex items-center gap-2">
                <div className="h-8 w-32 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
                <div className="h-8 w-32 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
            </div>
      </div>
      
      <div className="text-center py-4">
        <p className="text-lg font-semibold text-primary">{loadingMessage}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark flex flex-col items-center justify-center">
            <div className="h-6 w-3/4 bg-gray-300 dark:bg-gray-700 rounded mb-4"></div>
            <div className="w-48 h-24 bg-gray-200 dark:bg-gray-700 rounded-full" style={{clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)'}}></div>
        </div>
        <div className="md:col-span-2 bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark">
          <div className="h-6 w-1/4 bg-gray-300 dark:bg-gray-700 rounded mb-4"></div>
          <div className="space-y-2">
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
          </div>
          <div className="h-6 w-1/4 bg-gray-300 dark:bg-gray-700 rounded mt-6 mb-4"></div>
          <div className="space-y-2">
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-11/12"></div>
          </div>
        </div>
      </div>
      
      <SkeletonCard />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SkeletonCard />
        <SkeletonCard />
      </div>

       <SkeletonCard />
       <SkeletonCard />
    </div>
  );
};

export default ResultsDashboardSkeleton;