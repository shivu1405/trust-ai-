
import React from 'react';

interface CredibilityGaugeProps {
  score: number;
}

const CredibilityGauge: React.FC<CredibilityGaugeProps> = ({ score }) => {
  const normalizedScore = Math.max(0, Math.min(100, score));
  const angle = (normalizedScore / 100) * 180;
  const color = normalizedScore > 70 ? '#22c55e' : normalizedScore > 40 ? '#f59e0b' : '#ef4444';

  const describeArc = (x: number, y: number, radius: number, startAngle: number, endAngle: number) => {
    const start = {
      x: x + radius * Math.cos((startAngle-90) * Math.PI / 180),
      y: y + radius * Math.sin((startAngle-90) * Math.PI / 180)
    };
    const end = {
      x: x + radius * Math.cos((endAngle-90) * Math.PI / 180),
      y: y + radius * Math.sin((endAngle-90) * Math.PI / 180)
    };
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
    return `M ${start.x} ${start.y} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${end.x} ${end.y}`;
  };

  return (
    <div className="relative w-48 h-24">
      <svg width="192" height="96" viewBox="0 0 192 96">
        <path d={describeArc(96, 96, 80, 0, 180)} fill="none" stroke="currentColor" className="text-gray-200 dark:text-gray-700" strokeWidth="16" />
        <path d={describeArc(96, 96, 80, 0, angle)} fill="none" stroke={color} strokeWidth="16" strokeLinecap="round" />
      </svg>
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 text-center">
        <span className="text-4xl font-bold" style={{ color }}>{normalizedScore}</span>
        <span className="text-lg font-medium" style={{ color }}>%</span>
      </div>
    </div>
  );
};

export default CredibilityGauge;
