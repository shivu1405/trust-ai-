import React from 'react';
import { EntityAnalysis } from '../types';
import { ArrowRight } from './Icons';

interface EntityRelationshipGraphProps {
  entityAnalysis: EntityAnalysis;
}

const EntityRelationshipGraph: React.FC<EntityRelationshipGraphProps> = ({ entityAnalysis }) => {
  const { keyEntities, relationships, imageDescriptions } = entityAnalysis;

  // Memoize the regex for performance
  const entityRegex = React.useMemo(() => {
    if (!keyEntities || keyEntities.length === 0) return null;
    // Sort by length descending to match longer names first (e.g., "New York City" before "New York")
    const sortedNames = [...keyEntities].sort((a, b) => b.name.length - a.name.length);
    // Escape special regex characters in names
    const escapedNames = sortedNames.map(e => e.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    return new RegExp(`(${escapedNames.join('|')})`, 'g');
  }, [keyEntities]);

  const highlightEntities = (text: string) => {
    if (!entityRegex) return text;

    return text.split(entityRegex).map((part, index) => {
      // Check if the part is one of the entity names
      const isEntity = keyEntities.some(e => e.name === part);
      if (isEntity) {
        return (
          <strong key={index} className="font-bold text-primary dark:text-primary-light bg-primary/10 dark:bg-primary-light/10 px-1 py-0.5 rounded">
            {part}
          </strong>
        );
      }
      return part;
    });
  };

  return (
    <div className="space-y-6">
      {keyEntities.length > 0 && (
        <div>
          <h4 className="font-semibold text-sm mb-3 text-text-light dark:text-text-dark">Key Entities</h4>
          <div className="flex flex-wrap gap-2">
            {keyEntities.map((entity, index) => (
              <span key={index} className="px-2.5 py-1 text-xs font-medium bg-background-light dark:bg-background-dark text-text-secondary-light dark:text-text-secondary-dark border border-border-light dark:border-border-dark rounded-full">
                {entity.name} <span className="opacity-70">({entity.type})</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {relationships.length > 0 && (
        <div>
          <h4 className="font-semibold text-sm mb-3 text-text-light dark:text-text-dark">Relationships</h4>
          <ul className="space-y-2">
            {relationships.map((rel, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-text-secondary-light dark:text-text-secondary-dark">
                <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
                <span>{highlightEntities(rel)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {imageDescriptions.length > 0 && (
        <div>
          <h4 className="font-semibold text-sm mb-3 text-text-light dark:text-text-dark">Mentioned Images</h4>
          <ul className="space-y-2">
            {imageDescriptions.map((desc, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-text-secondary-light dark:text-text-secondary-dark">
                <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
                <span>{desc}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default EntityRelationshipGraph;