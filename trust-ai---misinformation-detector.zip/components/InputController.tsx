
import React, { useState, useRef, useCallback, useMemo } from 'react';
import { InputType } from '../types';
import VoiceInput from './VoiceInput';
import { FileText, Image, Link, Search, Type, X } from './Icons';

// This function reads the content of various file types as plain text.
const readFileAsText = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = (e) => reject(new Error("Could not read file content."));
        reader.readAsText(file);
    });
};


interface InputControllerProps {
  onAnalyze: (inputType: InputType, content: string, fileData: { name: string; type: string; data: string } | null) => void;
  isLoading: boolean;
}

type InputTab = 'text' | 'image' | 'file';

const InputController: React.FC<InputControllerProps> = ({ onAnalyze, isLoading }) => {
  const [activeTab, setActiveTab] = useState<InputTab>('text');
  const [inputValue, setInputValue] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isUrl = useMemo(() => /^(ftp|http|https):\/\/[^ "]+$/.test(inputValue), [inputValue]);

  const resetState = () => {
    setInputValue('');
    setFile(null);
  };
  
  const handleTabClick = (tab: InputTab) => {
    resetState();
    setActiveTab(tab);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setFile(event.target.files[0]);
    }
    if(fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAnalyzeClick = async () => {
    if (isLoading) return;

    if (activeTab === 'image' && file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64Data = (e.target?.result as string).split(',')[1];
        onAnalyze(InputType.IMAGE, '', { name: file.name, type: file.type, data: base64Data });
      };
      reader.readAsDataURL(file);
    } else if (activeTab === 'file' && file) {
      const textContent = await readFileAsText(file);
      onAnalyze(InputType.FILE, textContent, { name: file.name, type: file.type, data: '' });
    } else if (activeTab === 'text' && inputValue.trim()) {
      const type = isUrl ? InputType.URL : InputType.TEXT;
      onAnalyze(type, inputValue, null);
    }
  };
  
  const handleVoiceTranscript = useCallback((transcript: string) => {
    handleTabClick('text');
    setInputValue(prev => prev ? `${prev} ${transcript}`.trim() : transcript);
  }, []);
  
  const canAnalyze = !isLoading && ((activeTab === 'text' && !!inputValue.trim()) || (activeTab !== 'text' && !!file));

  return (
    <div className="bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark shadow-md sticky top-24">
      <h2 className="text-lg font-bold mb-4">Create New Analysis</h2>
      
      <div className="flex border-b border-border-light dark:border-border-dark mb-4">
        <TabButton icon={<Type/>} active={activeTab === 'text'} onClick={() => handleTabClick('text')}>Text & URL</TabButton>
        <TabButton icon={<Image/>} active={activeTab === 'image'} onClick={() => handleTabClick('image')}>Image</TabButton>
        <TabButton icon={<FileText/>} active={activeTab === 'file'} onClick={() => handleTabClick('file')}>File</TabButton>
      </div>

      <div className="min-h-[160px]">
        {activeTab === 'text' && <TextUrlInput value={inputValue} onChange={setInputValue} isUrl={isUrl} disabled={isLoading} />}
        {activeTab === 'image' && <FileInput type="image" file={file} setFile={setFile} fileInputRef={fileInputRef} onChange={handleFileChange} disabled={isLoading} />}
        {activeTab === 'file' && <FileInput type="file" file={file} setFile={setFile} fileInputRef={fileInputRef} onChange={handleFileChange} disabled={isLoading} />}
      </div>
      
       <div className="my-4">
        <VoiceInput onTranscript={handleVoiceTranscript} disabled={isLoading} />
      </div>

      <button
        onClick={handleAnalyzeClick}
        disabled={!canAnalyze}
        className="w-full flex items-center justify-center gap-2 bg-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-primary-dark disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors duration-200"
      >
        <Search className="h-5 w-5" />
        {isLoading ? 'Analyzing...' : 'Analyze'}
      </button>
    </div>
  );
};

// --- Sub-components for InputController ---

const TabButton: React.FC<{icon: React.ReactNode, active: boolean, onClick: ()=>void, children: React.ReactNode}> = ({icon, active, onClick, children}) => (
    <button onClick={onClick} className={`flex-1 flex items-center justify-center gap-2 p-3 text-sm font-semibold border-b-2 transition-colors ${active ? 'border-primary text-primary' : 'border-transparent text-text-secondary-light dark:text-text-secondary-dark hover:text-primary'}`}>
       <div className="w-5 h-5">{icon}</div> {children}
    </button>
);

const TextUrlInput: React.FC<{value: string, onChange: (v:string)=>void, isUrl: boolean, disabled: boolean}> = ({value, onChange, isUrl, disabled}) => (
    <div className="relative">
        <div className="absolute top-3 left-0 pl-3 flex items-center pointer-events-none">
            {isUrl ? <Link className="h-5 w-5 text-gray-400" /> : <Type className="h-5 w-5 text-gray-400" />}
        </div>
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          rows={6}
          className="w-full pl-10 pr-4 py-3 bg-background-light dark:bg-background-dark border border-border-light dark:border-border-dark rounded-lg focus:ring-2 focus:ring-primary focus:outline-none transition-all duration-200 resize-none disabled:opacity-50"
          placeholder="Enter text or paste a URL..."
        />
      </div>
);

const FileInput: React.FC<{type: 'image' | 'file', file: File | null, setFile: (f:File|null)=>void, fileInputRef: React.RefObject<HTMLInputElement>, onChange: (e: React.ChangeEvent<HTMLInputElement>)=>void, disabled:boolean}> = ({type, file, setFile, fileInputRef, onChange, disabled}) => {
    const accept = type === 'image' ? 'image/*' : '.pdf,.txt,.xml';
    const Icon = type === 'image' ? Image : FileText;
    const text = type === 'image' ? 'Image' : 'File';
    
    return (
        <div>
            {file ? (
                <div className="p-3 bg-background-light dark:bg-background-dark rounded-lg">
                    {type === 'image' && <img src={URL.createObjectURL(file)} alt="Preview" className="max-h-28 rounded-md mx-auto mb-2" />}
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 overflow-hidden">
                            <Icon className="h-5 w-5 text-primary flex-shrink-0" />
                            <span className="text-sm font-medium truncate">{file.name}</span>
                        </div>
                        <button onClick={() => setFile(null)} disabled={disabled} className="p-1 rounded-full hover:bg-gray-300 dark:hover:bg-gray-600 disabled:opacity-50">
                            <X className="h-4 w-4" />
                        </button>
                    </div>
                </div>
            ) : (
                 <button 
                    onClick={() => fileInputRef.current?.click()}
                    disabled={disabled}
                    className="w-full h-40 flex flex-col items-center justify-center gap-2 text-sm font-medium rounded-lg border-2 border-dashed border-border-light dark:border-border-dark text-text-secondary-light dark:text-text-secondary-dark hover:border-primary hover:text-primary dark:hover:border-primary-light dark:hover:text-primary-light transition-colors disabled:opacity-50"
                 >
                    <Icon className="h-8 w-8" /> Upload {text}
                </button>
            )}
            <input type="file" ref={fileInputRef} onChange={onChange} className="hidden" accept={accept} />
        </div>
    );
};

export default InputController;
