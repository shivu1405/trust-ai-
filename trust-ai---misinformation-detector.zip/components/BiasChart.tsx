
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { AnalysisResult } from '../types';

interface BiasChartProps {
  sentiment: AnalysisResult['sentiment'];
}

const BiasChart: React.FC<BiasChartProps> = ({ sentiment }) => {
    const data = [
        { name: 'Tone', value: sentiment.tone },
        { name: 'Bias', value: sentiment.bias },
        { name: 'Sentiment Score', value: sentiment.score, isScore: true }
    ];

    const sentimentColor = sentiment.score > 20 ? '#22c55e' : sentiment.score < -20 ? '#ef4444' : '#f59e0b';

  return (
    <div className="h-48">
        <div className="grid grid-cols-3 gap-4 text-center mb-4">
             <div>
                <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark">Tone</p>
                <p className="font-semibold">{sentiment.tone}</p>
            </div>
             <div>
                <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark">Bias</p>
                <p className="font-semibold">{sentiment.bias}</p>
            </div>
             <div>
                <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark">Sentiment</p>
                <p className="font-semibold" style={{ color: sentimentColor }}>{sentiment.score}</p>
            </div>
        </div>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={[{ name: 'Sentiment', score: sentiment.score }]} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
          <XAxis type="number" domain={[-100, 100]} hide />
          <YAxis type="category" dataKey="name" hide />
          <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ background: 'rgba(30, 41, 59, 0.8)', border: 'none', borderRadius: '0.5rem' }} />
          <Bar dataKey="score" barSize={20} radius={[10, 10, 10, 10]}>
             <Cell fill={sentimentColor} />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BiasChart;
