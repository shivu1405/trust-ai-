import React from 'react';
import { AnalysisResult } from '../types';
import CredibilityGauge from './CredibilityGauge';
import BiasChart from './BiasChart';
import SourcesList from './SourcesList';
import EntityRelationshipGraph from './EntityRelationshipGraph';
import { Download, ThumbsUp, ThumbsDown, RefreshCw, MessageSquare, Info, BarChart2, Check, FileText, Share2 } from './Icons';

interface ResultsDashboardProps {
  result: AnalysisResult;
  onNewAnalysis: () => void;
  onFollowUp: (question: string) => void;
}

const ResultCard: React.FC<{icon: React.ReactNode, title: string, children: React.ReactNode}> = ({icon, title, children}) => (
    <div className="bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark">
        <h3 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <div className="w-5 h-5 text-primary">{icon}</div> {title}
        </h3>
        {children}
    </div>
);


const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ result, onNewAnalysis, onFollowUp }) => {
  const { summary, credibility, sentiment, unbiasedVersion, sources, insights, followUpQuestions, entityAnalysis } = result;

  const generateReport = () => {
    let report = `Trust AI Analysis Report\n=========================\n\n`;
    report += `Summary:\n${summary}\n\n`;
    report += `Credibility Score: ${credibility.score}% (Confidence: ${credibility.confidence}%)\n`;
    report += `Explanation: ${credibility.explanation}\n\n`;
    report += `Insights & Metadata (${insights.title}):\n`;
    insights.items.forEach(item => {
        report += `  - ${item.key}: ${item.value}\n`;
    });
    if (entityAnalysis) {
        report += `\nKey Entities & Insights:\n`;
        report += `  - Entities: ${entityAnalysis.keyEntities.map(e => `${e.name} (${e.type})`).join(', ')}\n`;
        report += `  - Relationships:\n${entityAnalysis.relationships.map(r => `    - ${r}`).join('\n')}\n`;
    }
    report += `\nSentiment Analysis:\n`;
    report += `  - Tone: ${sentiment.tone}, Bias: ${sentiment.bias}, Score: ${sentiment.score}\n\n`;
    report += `Rewritten Unbiased Version:\n${unbiasedVersion}\n\n`;
    report += `Verified Sources:\n`;
    sources.verified.forEach(s => { report += `  - ${s.title} (${s.url}) [Trust: ${s.trustScore}%]\n`; });
    report += `\nNon-Verified Sources:\n`;
    sources.nonVerified.forEach(s => { report += `  - ${s.title} (${s.url}) [Trust: ${s.trustScore}%]\n`; });

    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Trust-AI-Report.txt';
    a.click();
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="space-y-6">
       <div className="flex flex-wrap justify-between items-center gap-4">
        <h2 className="text-2xl font-bold">Analysis Results</h2>
        <div className="flex items-center gap-2">
            <button onClick={generateReport} className="flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg text-primary bg-primary/10 hover:bg-primary/20 transition-colors">
                <Download className="h-4 w-4" /> Download Report
            </button>
             <button onClick={onNewAnalysis} className="flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg text-primary bg-primary/10 hover:bg-primary/20 transition-colors">
                <RefreshCw className="h-4 w-4" /> New Analysis
            </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark flex flex-col items-center justify-center">
            <h3 className="text-lg font-semibold mb-4">Credibility Score</h3>
            <CredibilityGauge score={credibility.score} />
            <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark mt-2">Confidence: {credibility.confidence}%</p>
        </div>
        <div className="md:col-span-2 bg-card-light dark:bg-card-dark p-6 rounded-xl border border-border-light dark:border-border-dark">
          <h3 className="text-lg font-semibold mb-2">Summary</h3>
          <p className="text-sm text-text-secondary-light dark:text-text-secondary-dark">{summary}</p>
          <h3 className="text-lg font-semibold mt-4 mb-2">Explanation</h3>
          <p className="text-sm text-text-secondary-light dark:text-text-secondary-dark">{credibility.explanation}</p>
        </div>
      </div>
      
      <ResultCard icon={<MessageSquare />} title="Follow-up Guide">
        <p className="text-sm text-text-secondary-light dark:text-text-secondary-dark mb-3">Ask our AI assistant for more details:</p>
        <div className="flex flex-wrap gap-2">
            {followUpQuestions.map((q, i) => (
                <button key={i} onClick={() => onFollowUp(q)} className="px-3 py-1.5 text-xs font-medium bg-background-light dark:bg-background-dark rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
                    {q}
                </button>
            ))}
        </div>
      </ResultCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ResultCard icon={<BarChart2/>} title="Bias & Sentiment">
            <BiasChart sentiment={sentiment} />
        </ResultCard>
        <ResultCard icon={<Info/>} title={insights.title}>
            <div className="space-y-2 text-sm">
                {insights.items.map(item => (
                    <div key={item.key} className="flex justify-between">
                        <span className="font-medium text-text-secondary-light dark:text-text-secondary-dark">{item.key}:</span>
                        <span className="font-semibold text-right">{item.value}</span>
                    </div>
                ))}
            </div>
        </ResultCard>
      </div>

       {entityAnalysis && (entityAnalysis.keyEntities.length > 0 || entityAnalysis.relationships.length > 0) && (
        <ResultCard icon={<Share2 />} title="Key Insights & Entities">
          <EntityRelationshipGraph entityAnalysis={entityAnalysis} />
        </ResultCard>
      )}

       <ResultCard icon={<Check/>} title="Unbiased Version">
          <p className="text-sm text-text-secondary-light dark:text-text-secondary-dark italic bg-background-light dark:bg-background-dark p-4 rounded-lg">{unbiasedVersion}</p>
       </ResultCard>

      <ResultCard icon={<FileText />} title="Sources">
        <SourcesList sources={sources} />
      </ResultCard>

       <div className="flex justify-center items-center gap-4 pt-4">
        <p className="text-sm text-text-secondary-light dark:text-text-secondary-dark">Was this analysis helpful?</p>
        <button className="flex items-center gap-2 px-3 py-1 text-sm rounded-full border border-green-500 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/50 transition-colors"><ThumbsUp className="h-4 w-4" /> Accurate</button>
        <button className="flex items-center gap-2 px-3 py-1 text-sm rounded-full border border-red-500 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/50 transition-colors"><ThumbsDown className="h-4 w-4" /> Inaccurate</button>
      </div>
    </div>
  );
};

export default ResultsDashboard;