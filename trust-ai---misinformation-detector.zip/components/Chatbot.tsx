import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send } from './Icons';

interface ChatbotProps {
    isOpen: boolean;
    onOpen: () => void;
    onClose: () => void;
    messages: { role: 'user' | 'model'; text: string }[];
    onSend: (message: string, currentMessages: { role: 'user' | 'model'; text: string }[]) => void;
    setMessages: React.Dispatch<React.SetStateAction<{ role: 'user' | 'model'; text: string }[]>>;
}

const Chatbot: React.FC<ChatbotProps> = ({ isOpen, onOpen, onClose, messages, onSend, setMessages }) => {
    const [inputValue, setInputValue] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages, isTyping]);

    useEffect(() => {
        if(messages.length > 0 && messages[messages.length - 1].role === 'user') {
            setIsTyping(true);
        } else {
            setIsTyping(false);
        }
    }, [messages]);

    const handleSend = () => {
        if (inputValue.trim()) {
            // FIX: Use 'as const' to ensure TypeScript infers the literal type 'user' for the role,
            // which satisfies the `{ role: 'user' | 'model'; ... }` type expected by the state.
            const currentMessages = [...messages, { role: 'user' as const, text: inputValue }];
            setMessages(currentMessages);
            setIsTyping(true);
            onSend(inputValue, currentMessages);
            setInputValue('');
        }
    };
    
    return (
        <>
            {/* Chat Window */}
            <div className={`fixed bottom-24 right-4 md:right-8 w-[calc(100%-2rem)] max-w-sm h-[60vh] bg-card-light dark:bg-card-dark rounded-xl shadow-2xl flex flex-col transition-transform duration-300 ease-in-out z-40 ${isOpen ? 'translate-y-0 opacity-100' : 'translate-y-16 opacity-0 pointer-events-none'}`}>
                <header className="flex items-center justify-between p-4 border-b border-border-light dark:border-border-dark">
                    <h3 className="font-bold text-lg">Trust AI Assistant</h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
                        <X className="h-5 w-5" />
                    </button>
                </header>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-end gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs md:max-w-sm px-4 py-2 rounded-2xl ${msg.role === 'user' ? 'bg-primary text-white rounded-br-none' : 'bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark rounded-bl-none'}`}>
                                <p className="text-sm">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    {isTyping && (
                         <div className="flex items-end gap-2 justify-start">
                            <div className="max-w-xs md:max-w-sm px-4 py-2 rounded-2xl bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark rounded-bl-none">
                                <div className="flex items-center justify-center gap-1.5">
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <div className="p-4 border-t border-border-light dark:border-border-dark">
                    <div className="flex items-center gap-2">
                        <input
                            type="text"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask a question..."
                            className="flex-1 w-full px-4 py-2 bg-background-light dark:bg-background-dark border border-border-light dark:border-border-dark rounded-full focus:ring-2 focus:ring-primary focus:outline-none"
                        />
                        <button onClick={handleSend} className="p-2 bg-primary text-white rounded-full hover:bg-primary-dark transition-colors">
                            <Send className="h-5 w-5" />
                        </button>
                    </div>
                </div>
            </div>

            {/* FAB */}
            <button
                onClick={onOpen}
                className="fixed bottom-4 right-4 md:right-8 w-16 h-16 bg-primary text-white rounded-full shadow-lg flex items-center justify-center hover:bg-primary-dark transition-transform duration-200 ease-in-out hover:scale-110 z-50"
                aria-label="Open Chat"
            >
                <MessageSquare className="h-8 w-8" />
            </button>
        </>
    );
};

export default Chatbot;