
import React from 'react';
import { AnalysisResult } from '../types';
import { CheckCircle, XCircle, ExternalLink } from './Icons';

interface SourcesListProps {
  sources: AnalysisResult['sources'];
}

const SourcesList: React.FC<SourcesListProps> = ({ sources }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <h4 className="font-semibold flex items-center gap-2 mb-3"><CheckCircle className="h-5 w-5 text-green-500" /> Verified Sources</h4>
        <div className="space-y-2">
          {sources.verified.length > 0 ? sources.verified.map((source, index) => (
            <div key={index} className="p-3 bg-background-light dark:bg-background-dark rounded-md text-sm">
                <div className="flex justify-between items-center">
                    <a href={source.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 font-medium text-primary hover:underline w-full truncate pr-2">
                       {source.title} <ExternalLink className="h-3 w-3 flex-shrink-0"/>
                    </a>
                    <span className="text-green-500 font-bold text-xs flex-shrink-0">{source.trustScore}%</span>
                </div>
            </div>
          )) : <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark p-3">No verified sources found.</p>}
        </div>
      </div>
      <div>
        <h4 className="font-semibold flex items-center gap-2 mb-3"><XCircle className="h-5 w-5 text-red-500" /> Non-Verified Sources</h4>
        <div className="space-y-2">
          {sources.nonVerified.length > 0 ? sources.nonVerified.map((source, index) => (
             <div key={index} className="p-3 bg-background-light dark:bg-background-dark rounded-md text-sm">
                 <div className="flex justify-between items-center">
                    <a href={source.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 font-medium text-primary hover:underline w-full truncate pr-2">
                       {source.title} <ExternalLink className="h-3 w-3 flex-shrink-0"/>
                    </a>
                    <span className="text-red-500 font-bold text-xs flex-shrink-0">{source.trustScore}%</span>
                </div>
            </div>
          )) : <p className="text-xs text-text-secondary-light dark:text-text-secondary-dark p-3">No non-verified sources found.</p>}
        </div>
      </div>
    </div>
  );
};

export default SourcesList;
