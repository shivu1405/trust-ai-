
import React from 'react';
import { X } from './Icons';

interface ModalProps {
    onClose: () => void;
    title: string;
    children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ onClose, title, children }) => {
    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-card-light dark:bg-card-dark rounded-xl shadow-2xl max-w-2xl w-full mx-auto p-6 relative" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold">{title}</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>
                <div className="prose dark:prose-invert max-w-none text-text-light dark:text-text-dark text-sm max-h-[70vh] overflow-y-auto pr-3">
                    {children}
                </div>
            </div>
        </div>
    );
};

export const LearnModal: React.FC<{onClose: () => void}> = ({onClose}) => (
    <Modal onClose={onClose} title="Learn About Misinformation">
        <h4>What is Misinformation?</h4>
        <p>Misinformation is false or inaccurate information that is spread, regardless of intent to deceive. It can be harmful as it erodes trust, impacts public health, and influences democratic processes.</p>
        
        <h4>How AI Helps</h4>
        <p>AI tools like Trust AI analyze vast amounts of data to identify patterns associated with misinformation. This includes checking claims against reputable sources, detecting biased or manipulative language, and verifying the authenticity of images and media.</p>
        
        <h4>Key things to look for:</h4>
        <ul>
            <li><strong>Check the Source:</strong> Is it a reputable news organization or an unknown blog?</li>
            <li><strong>Look for Bias:</strong> Does the language seem emotionally charged or one-sided?</li>
            <li><strong>Verify with Multiple Sources:</strong> Do other trusted sources report the same information?</li>
            <li><strong>Examine the Evidence:</strong> Are claims supported by facts and data?</li>
        </ul>
    </Modal>
);

export const TransparencyModal: React.FC<{onClose: () => void}> = ({onClose}) => (
     <Modal onClose={onClose} title="Model Transparency">
        <h4>Our Technology</h4>
        <p>Trust AI is powered by Google's Gemini family of models. These are large-scale language models trained to understand and generate human-like text, analyze images, and process complex information.</p>
        
        <h4>Limitations of AI</h4>
        <p>While powerful, AI is not infallible. It can make mistakes, misinterpret context, or reflect biases present in its training data. Key limitations include:</p>
        <ul>
            <li><strong>Nuance and Sarcasm:</strong> AI may struggle to understand complex human communication like satire.</li>
            <li><strong>Evolving Information:</strong> For breaking news, information changes rapidly, and the AI's knowledge might not be up-to-the-minute.</li>
            <li><strong>Data Bias:</strong> The AI's training data may contain historical or societal biases, which can sometimes influence its analysis.</li>
        </ul>
        
        <h4>Our Commitment</h4>
        <p>We are committed to continuously improving our models and providing you with the most accurate and unbiased analysis possible. We display a "confidence score" with each analysis to indicate the AI's own assessment of its accuracy. User feedback is crucial for helping us refine our system.</p>
    </Modal>
);
